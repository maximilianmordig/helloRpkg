library(testthat)
library(helloRpkg)

test_check("helloRpkg")
