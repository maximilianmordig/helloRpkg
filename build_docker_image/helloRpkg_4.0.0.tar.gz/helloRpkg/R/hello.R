
#' Hello World
#'
#' THis is a hello world function
#'
#'
#' @param name string with name
#'
#' @return nothing
#'
#' @export
#'
#' @examples
#' hello("max")
#'
hello <- function(name) {
  print(paste("HelloR2", name))
}

print(paste("Hello", "te"))

