

#' Foo function
#'
#' a foo function
#'
#'
#' @param x x argument
#'
#'
#' @export
#'
#' @return NULL
#'
#' @examples
#'
#' foo("abcd")
#'
foo <- function(x) {
  print(paste("foo:", x))
}
