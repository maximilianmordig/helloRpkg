
#' zzz function
#'
#' a zzz function
#'
#'
#' @param x x argument
#'
#'
#' @export
#'
#' @return NULL
#'
#' @examples
#'
#' zzz("abcd")
#'
zzz <- function(x) {
  print(paste("zzz:", x))
}
