

#' uuu function
#'
#' a uuu function
#'
#'
#' @param x x argument
#'
#'
#' @export
#'
#' @return NULL
#'
#' @examples
#'
#' uuu("abcd")
#'
uuu <- function(x) {
  print(paste("uuu:", x))
}
