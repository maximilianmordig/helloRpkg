

#' bar function
#'
#' a bar function
#'
#'
#' @param x x argument
#'
#'
#' @export
#'
#' @return NULL
#'
#' @examples
#'
#' bar("abcd")
#'
bar <- function(x) {
  print(paste("bar:", x))
}
