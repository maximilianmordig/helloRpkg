

#' iii function
#'
#' a iii function
#'
#'
#' @param x x argument
#'
#'
#' @export
#'
#' @return NULL
#'
#' @examples
#'
#' iii("abcd")
#'
iii <- function(x) {
  print(paste("iii:", x))
}
